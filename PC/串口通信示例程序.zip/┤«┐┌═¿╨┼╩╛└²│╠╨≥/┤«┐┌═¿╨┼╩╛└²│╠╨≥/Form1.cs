﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;  //调用该名命名空间以进行串口通信
//你可以去网上下载一个虚拟串口助手，在你的电脑上创建虚拟串口，这样就可以通过串口猎人来调试你自己的GUI程序了

namespace 串口通信示例程序
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
                serialPort1.Open();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
                serialPort1.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            serialPort1.Write(textBox1.Text);
            //注意这里别用WriteLine()发送数据，网上用很多教程都是让你用WriteLine()，但是WriteLine()会在你发送的字符串末尾自动加上\n再发送，这样就可能会导致一些问题
        }

        //下面这段代码需要设置一下才能够用，当然本例已经设置好了
        //点击serialPort1控件，visual studio的右侧栏你仔细找会看到一个小小的闪电按钮，这个按钮就是用来设置事件的
        //点击这个按钮，把DataRecieved设置成serialPort1_DataReceived即可
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)     //接收数据
        {
            string s = "";
            int count = serialPort1.BytesToRead;

            byte[] data = new byte[count];
            serialPort1.Read(data, 0, count);

            foreach (byte item in data)
            {
                s += Convert.ToChar(item);
            }
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate { label2.Text = s; }));       //花括号内定义接收数据后的操作，这里其实建议把s赋给一个全局变量，这样就可以在程序的任意位置访问了。当然要是想实现更多的功能，你也可以写一个方法在这里调用。
            }
            else
            {
                MessageBox.Show("Serial port invokes error!!");
            }
        }
    }
}
