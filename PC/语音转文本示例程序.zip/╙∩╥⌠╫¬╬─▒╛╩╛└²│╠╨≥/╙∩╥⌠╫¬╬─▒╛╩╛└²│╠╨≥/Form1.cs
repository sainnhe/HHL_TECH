﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;        //System.Speech
//要调用这个命名空间需要添加引用
//项目 -> 添加引用 -> 程序集 -> 搜索System.Speech ->勾选并点击确定
//本例采用单线程语音识别，因此识别过程中程序会卡住动不了，直到语音识别结束。要解决这个问题可以把语音识别放到多线程当中
//另外本例采用的是微软自带的离线语音识别函数库，英文识别还将就，中文识别正确率比较低。
//不过也可以通过修改代码的方式来提高识别正确率，比如说要是把“可乐”识别成了“克勒”，那就if (str=="可乐"||str=="克勒")
//不过有能力的同学还是建议调用API进行在线语音识别，正确率精准度会高得多
//其实当初搞语音识别这玩意说好听点是为了拿分高一点，说难听点纯粹为了装逼，结果在最后一天把语音识别砍掉了，因为现场太吵。
//总之想做语音识别的你们看着办吧
//我们这一届貌似是没有人把语音识别搞出来的，但是有人把人脸识别搞出来了，，

namespace 语音转文本示例程序
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = Speech_Recognition("zh-CN");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = Speech_Recognition("en-US");
        }

        string Speech_Recognition(string language)
        {
            string to_be_returned;      //定义字符串参数，作为返回值
            SpeechRecognitionEngine recognizer = new SpeechRecognitionEngine(new System.Globalization.CultureInfo(language));   //实例化
            Grammar dictationGrammar = new DictationGrammar();      //实例化
            recognizer.LoadGrammar(dictationGrammar);       //初始化
            try
            {
                recognizer.SetInputToDefaultAudioDevice();
                RecognitionResult result = recognizer.Recognize();
                if (result != null)
                    to_be_returned = result.Text;       //识别成功则返回识别出来的文本
                else
                {
                    to_be_returned = "|invalid|";       //识别失败则返回这个字符串
                    //Speech_Recognition(language);         //并递归调用本方法
                    //去掉上面那行注释之后一旦识别失败就会再次开始语音识别，直到识别正确为止
                }
            }
            catch (InvalidOperationException exception)
            {
                to_be_returned = "|error|";         //识别错误则返回这个字符串
            }
            finally
            {
                recognizer.UnloadAllGrammars();
            }
            return to_be_returned;
            //另外这里也可以不采用返回值的方式，也可以直接在最后将to_be_returned赋值给一个全局变量，这样会更加方便
        }
    }
}
