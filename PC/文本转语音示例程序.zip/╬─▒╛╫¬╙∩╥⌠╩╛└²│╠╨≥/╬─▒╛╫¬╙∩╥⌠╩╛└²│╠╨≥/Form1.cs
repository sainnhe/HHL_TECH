﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SpeechLib;                        //Microsoft Speech Object Library in C
//要调用这个命名空间需要添加引用
//项目 -> 添加引用 -> COM -> 搜索Microsoft Speech Object Library in C ->勾选并点击确定

namespace 文本转语音示例程序
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SpVoice voice = new SpVoice();//SAPI 5.4
            voice.Voice = voice.GetVoices(string.Empty, string.Empty).Item(0);
            voice.Speak("这个字符串就是将会被朗读的文本，either Chinese or English will do");
            //同步朗读程序会卡住，直到文本朗读完毕
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SpVoice voice = new SpVoice();//SAPI 5.4
            voice.Voice = voice.GetVoices(string.Empty, string.Empty).Item(0);
            voice.Speak("通院你他妈改革改尼玛呢？啊？？", SpeechVoiceSpeakFlags.SVSFlagsAsync);
            //异步朗读程序不会卡住，朗读文本的同时程序可以干其它的事情
        }
    }
}
