#include <stdint.h>
#include <stdbool.h>
#include "hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pwm.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom_map.h"
#include "inc/hw_i2c.h"
#include "driverlib/i2c.h"
#include "utils/uartstdio.h"
#include "utils/softi2c.h"
#include "driverlib/systick.h"
#include "driverlib/rom.h"
#include "inc/hw_nvic.h"
#include "driverlib/fpu.h"
#include "TCS34725_file.h"
#include "driverlib/debug.h"
#include "VL6180.h"

    //颜色传感器变量声明
    char colorget;
    float rgb[3];
    uint8_t readdata[8];
    uint16_t c,r,g,b;

    //距离传感器变量声明
    uint16_t distance;
    uint32_t breakflag;

    //读卡模块变量声明
    uint8_t allergy[8]="all0000*";
    uint8_t cardflag1[4];
    uint8_t cardflag2[4];
    uint8_t testcardbox[6]="#****#";

    //串口通信变量声明
    uint32_t i;
    uint32_t doit;
    uint32_t cmp=0;
    uint32_t shippingangel;
    uint8_t dataspace[8];
    uint32_t g_ui32SysClock;

    //货物变量声明
    uint8_t colorlist[20]="******************gr";
    uint8_t colorlist1[5]="*****";
    uint8_t colorlist2[5]="*****";
    uint8_t colorlist3[5]="*****";
    uint8_t colorlist4[5]="***gr";
    uint8_t shippingbox[18]="******************";

//串口使能
void ConfigureUART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTStdioConfig(0, 115200,  g_ui32SysClock);
}

//I2C协议初始化
void I2C_Init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);
    GPIOPinTypeI2C(GPIO_PORTB_BASE,GPIO_PIN_3);
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE,GPIO_PIN_2);
    I2CMasterInitExpClk(I2C0_BASE,SysCtlClockGet(), false);
    I2CMasterEnable(I2C0_BASE);
}

//MCU所有初始化及配置
void InitAll(void)
{
        g_ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 120000000);
        SysTickPeriodSet(SysCtlClockGet());
        SysTickEnable();
        ConfigureUART();
        I2C_Init();
        I2C2_Init();
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
        GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);
        GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);
        IntMasterEnable();
        UARTConfigSetExpClk(UART0_BASE, g_ui32SysClock, 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
        IntEnable(INT_UART0);
        UARTIntEnable(UART0_BASE, UART_INT_RX | UART_INT_RT);
        TCS34725_Enable();
        TCS34725_SetIntegrationTime(TCS34725_INTEGRATIONTIME_101MS);
        TCS34725_SetGain(TCS34725_GAIN_60X);
        Delay_ms(100);

        IIC_Init();
        VL6180X_Init();

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOM);
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
        GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, (GPIO_PIN_0|GPIO_PIN_1));
        GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, (GPIO_PIN_4|GPIO_PIN_5));
        GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, (GPIO_PIN_4|GPIO_PIN_6|GPIO_PIN_7));
        GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5));

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);
        GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, (GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3));

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
        GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, (GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3));
}

//发送字符串函数
void UARTSend(const uint8_t *pui8Buffer, uint32_t ui32Count)
{
    while(ui32Count--)
    {
        UARTCharPutNonBlocking(UART0_BASE, *pui8Buffer++);
    }
}

//比对来自GUI的8位字符串
void Message(const uint8_t box[8])
{
    cmp=0;
    for(i = 0; i < 8; i++)
              {
                  if(dataspace[i]==box[i]) cmp++;
              }
    if(cmp>=8)  doit=1;
    else doit=0;
}

//比对控制转盘电机的字符串
void MessageMotor(const uint8_t motorbox[5],const uint8_t motorlist[5])
{
    cmp=0;
    for(i = 0; i < 5; i++)
              {
                  if(motorbox[i]==motorlist[i]) cmp++;
              }
    if(cmp>=5)  doit=1;
    else doit=0;
}

//接收来自GUI的8位字符串
void StringGet(void)
{
    for(i = 0; i < 8; i++)
    {
        dataspace[i] = UARTCharGet(UART0_BASE);
    }
}

void DivideFour(void)
{
    for(i=0;i<5;i++)
    {
        colorlist1[i]=colorlist[i];
    }
    for(i=0;i<5;i++)
    {
        colorlist2[i]=colorlist[i+5];
    }
    for(i=0;i<5;i++)
    {
        colorlist3[i]=colorlist[i+10];
    }
    for(i=0;i<3;i++)
    {
        colorlist4[i]=colorlist[i+15];
    }
}

void LoopSend(const uint8_t loopmessage[8])
{
    while(1)
    {
        UARTSend((uint8_t *)loopmessage,8);
        StringGet();
        Message("nextnext");
        if(doit==1)
        {
            UARTSend((uint8_t *)loopmessage,8);
        }
        Message("nicejob*");
        if(doit==1)
        {
            break;
        }
        Message("addgoods");
        if(doit==1)
        {
            breakflag=1;
            break;
        }
    }
}

void LoopSend5(const uint8_t loopmessage5[5])
{

    while(1)
    {
        UARTSend((uint8_t *)loopmessage5,5);
        StringGet();
        Message("nextnext");
        if(doit==1)
        {
            UARTSend((uint8_t *)loopmessage5,5);
            SysCtlDelay(g_ui32SysClock/12);
        }
        Message("nicejob*");
        if(doit==1)
        {
            break;
        }
    }
}

void SendColorlist(void)
{
    DivideFour();
    LoopSend5(colorlist4);
    SysCtlDelay(g_ui32SysClock/6);
    LoopSend5(colorlist3);
    SysCtlDelay(g_ui32SysClock/6);
    LoopSend5(colorlist2);
    SysCtlDelay(g_ui32SysClock/6);
    LoopSend5(colorlist1);
    SysCtlDelay(g_ui32SysClock/6);
}

//颜色传感器读取物块颜色
void ReadColor(void)
{
    while(1)
    {
        readdata[0]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_RDATAL|0x80);
        Delay_ms(10);
        readdata[1]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_RDATAH|0x80);
        Delay_ms(10);
        readdata[2]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_GDATAL|0x80);
        Delay_ms(10);
        readdata[3]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_GDATAH|0x80);
        Delay_ms(10);
        readdata[4]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_BDATAL|0x80);
        Delay_ms(10);
        readdata[5]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_BDATAH|0x80);
        Delay_ms(10);
        readdata[6]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_CDATAL|0x80);
        Delay_ms(10);
        readdata[7]=I2CMasterReadTCS34725(SLAVE_ADDRESS,TCS34725_CDATAH|0x80);
        Delay_ms(10);
        r=readdata[1];
        g=readdata[3];
        b=readdata[5];
        c=readdata[7];
        //UARTprintf("C: %d ",c);
        //UARTprintf("R: %d ",r);
        //UARTprintf("G: %d ",g);
        //UARTprintf("B: %d ",b);
        Delay_ms(100);
        rgb[0] = r/(float)c;
        rgb[1] = g/(float)c;
        rgb[2] = b/(float)c;

        if((rgb[0] >0.71)&&(rgb[0]<0.79)&&(rgb[1] >0.10)&&(rgb[1]<0.30)&&(rgb[2]>0.10)&&(rgb[2]<0.26))
                        {colorget='r';break;}
                        else if((rgb[0] >0.46)&&(rgb[0]<0.57)&&(rgb[1] >0.47)&&(rgb[1]<0.70)&&(rgb[2]>0.12)&&(rgb[2]<0.39))
                        {colorget='g';break;}
                        else if((rgb[0] >0.18)&&(rgb[0]<0.36)&&(rgb[1] >0.35)&&(rgb[1]<0.43)&&(rgb[2]>0.35)&&(rgb[2]<0.45))
                        {colorget='b';break;}
                        else if((rgb[0] >0.35)&&(rgb[0]<0.55)&&(rgb[1] >0.23)&&(rgb[1]<0.39)&&(rgb[2]>0.25)&&(rgb[2]<0.40))
                        {colorget='p';break;}
                        else if((rgb[0] >0.63)&&(rgb[0]<0.90)&&(rgb[1] >0.42)&&(rgb[1]<0.62)&&(rgb[2]>0.10)&&(rgb[2]<0.23))
                        {colorget='y';break;}
                        else if((rgb[0] >0.50)&&(rgb[0]<1.2)&&(rgb[1] >0.18)&&(rgb[1]<0.64)&&(rgb[2]>0.16)&&(rgb[2]<0.48))
                        {colorget='f';break;}
                        else if((rgb[0] >0.40)&&(rgb[0]<0.60)&&(rgb[1] >0.31)&&(rgb[1]<0.51)&&(rgb[2]>0.23)&&(rgb[2]<0.43))
                        {colorget='*';break;}
                        //else
                        //{colorget='*';break;}
    }
    //UARTprintf("test_color:%c",colorget);
    //UARTprintf("%c",colorget);
}

//距离传感器读取距离
void ReadDistance(void)
{
    while(1)
    {
        distance=RangePollingRead();
        //UARTprintf("#distance:%d#",distance);
        if(distance!=255)
        break;
    }
}

//红外传感器读取卡片敏感信息
void ReadCard(void)
{
    while(1)
    {
        if(GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_0))
            {cardflag1[0]='1';}
        else
            {cardflag1[0]='0';}
        if(GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_1))
            {cardflag1[1]='1';}
        else
            {cardflag1[1]='0';}
        if(GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_2))
            {cardflag1[2]='1';}
        else
            {cardflag1[2]='0';}
        if(GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_3))
            {cardflag1[3]='1';}
        else
            {cardflag1[3]='0';}
        allergy[3]=cardflag1[0];
        allergy[4]=cardflag1[1];
        allergy[5]=cardflag1[2];
        allergy[6]=cardflag1[3];
        break;
        /*if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_0))
            {cardflag1[0]='1';}
        else
            {cardflag1[0]='0';}
        cardflag2[0]=cardflag1[0];
        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_0))
            {cardflag1[0]='1';}
        else
            {cardflag1[0]='0';}

        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_1))
            {cardflag1[1]='1';}
        else
            {cardflag1[1]='0';}
        cardflag2[1]=cardflag1[1];
        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_1))
            {cardflag1[1]='1';}
        else
            {cardflag1[1]='0';}

        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_2))
            {cardflag1[2]='1';}
        else
            {cardflag1[2]='0';}
        cardflag2[2]=cardflag1[2];
        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_2))
            {cardflag1[2]='1';}
        else
            {cardflag1[2]='0';}

        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_3))
            {cardflag1[3]='1';}
        else
            {cardflag1[3]='0';}
        cardflag2[3]=cardflag1[3];
        if(GPIOPinRead(GPIO_PORTL_BASE,GPIO_PIN_3))
            {cardflag1[3]='1';}
        else
            {cardflag1[3]='0';}

        if(((cardflag2[0]==cardflag1[0])&&(cardflag2[1]==cardflag1[1])&&(cardflag2[2]==cardflag1[2])&&(cardflag2[3]==cardflag1[3]))==1)
                {
            allergy[3]=cardflag1[0];
            allergy[4]=cardflag1[1];
            allergy[5]=cardflag1[2];
            allergy[6]=cardflag1[3];
            break;
                }
        else
            continue;*/
    }
}

//对FPGA管脚进行写操作
void WritePin(const uint8_t writepinbox[5])
{
    while(1)
    {
        MessageMotor(writepinbox,"00000");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"00001");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"00010");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"00011");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"00100");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"00101");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"00110");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"00111");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"01000");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"01001");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"01010");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"01011");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"01100");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"01101");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"01110");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"01111");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,GPIO_PIN_6);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,GPIO_PIN_7);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
        MessageMotor(writepinbox,"10000");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,0);
                break;
            }
        }
        MessageMotor(writepinbox,"10001");
        {
            if(doit==1)
            {
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_4,GPIO_PIN_4);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_6,0);
                GPIOPinWrite(GPIO_PORTK_BASE,GPIO_PIN_7,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_4,0);
                GPIOPinWrite(GPIO_PORTM_BASE,GPIO_PIN_5,GPIO_PIN_5);
                break;
            }
        }
    }
}

//控制进货电机
void MotorPush(void)
{
    GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,0);
    SysCtlDelay(g_ui32SysClock/2);
    GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
    SysCtlDelay(g_ui32SysClock/2);
}

//控制出货电机
void MotorPop(void)
{
    GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,0);
    SysCtlDelay(g_ui32SysClock/2);
    GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,GPIO_PIN_5);
    SysCtlDelay(g_ui32SysClock/2);
}

//控制转盘电机转到指定角度
void MotorAngel(const uint32_t angel)
{
    switch(angel)
    {
    case 0:
        WritePin("00000");
        break;
    case 1:
        WritePin("00001");
        break;
    case 2:
        WritePin("00010");
        break;
    case 3:
        WritePin("00011");
        break;
    case 4:
        WritePin("00100");
        break;
    case 5:
        WritePin("00101");
        break;
    case 6:
        WritePin("00110");
        break;
    case 7:
        WritePin("00111");
        break;
    case 8:
        WritePin("01000");
        break;
    case 9:
        WritePin("01001");
        break;
    case 10:
        WritePin("01010");
        break;
    case 11:
        WritePin("01011");
        break;
    case 12:
        WritePin("01100");
        break;
    case 13:
        WritePin("01101");
        break;
    case 14:
        WritePin("01110");
        break;
    case 15:
        WritePin("01111");
        break;
    case 16:
        WritePin("10000");
        break;
    case 17:
        WritePin("10001");
        break;
    }
}

//驱动电机添加货物并完成一轮货物序列检测
void MotorAddScan(void)
{
    if(colorlist[0]=='*')
    {
        MotorAngel(0);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[0]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[1]=='*')
    {
        MotorAngel(1);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[1]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[2]=='*')
    {
        MotorAngel(2);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[2]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[3]=='*')
    {
        MotorAngel(3);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[3]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[4]=='*')
    {
        MotorAngel(4);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[4]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[5]=='*')
    {
        MotorAngel(5);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[5]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[6]=='*')
    {
        MotorAngel(6);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[6]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[7]=='*')
    {
        MotorAngel(7);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[7]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[8]=='*')
    {
        MotorAngel(8);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[8]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[9]=='*')
    {
        MotorAngel(9);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[9]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[10]=='*')
    {
        MotorAngel(10);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[10]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[11]=='*')
    {
        MotorAngel(11);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[11]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[12]=='*')
    {
        MotorAngel(12);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[12]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[13]=='*')
    {
        MotorAngel(13);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[13]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[14]=='*')
    {
        MotorAngel(14);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[14]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[15]=='*')
    {
        MotorAngel(15);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[15]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[16]=='*')
    {
        MotorAngel(16);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[16]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }

    if(colorlist[17]=='*')
    {
        MotorAngel(17);
        SysCtlDelay(g_ui32SysClock/6);
        MotorPush();
        SysCtlDelay(g_ui32SysClock/3);
        ReadColor();
        colorlist[17]=colorget;
        SysCtlDelay(g_ui32SysClock/6);
    }
}

void MotorReset(void)
{
    //电机复位
    GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,GPIO_PIN_5);
    GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
    SysCtlDelay(g_ui32SysClock/2);
    WritePin("00000");
    SysCtlDelay(g_ui32SysClock/6);
    WritePin("01001");
    SysCtlDelay(g_ui32SysClock/6);
    WritePin("00000");
    SysCtlDelay(g_ui32SysClock/6);
}

//控制转盘电机和出货电机进行出货操作
void ShippingGoods(void)
{
    while(1)
    {
        LoopSend("deliver*");
        StringGet();
        Message("ending**");
        if(doit==1)
        {
            break;
        }
        shippingangel=dataspace[0];
        if(shippingangel=='a') {GPIOPinWrite(GPIO_PORTN_BASE,GPIO_PIN_0,GPIO_PIN_0);}
        switch(shippingangel)
        {
        case '0':
            MotorAngel(9);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[0]='*';
            break;
        case '1':
            MotorAngel(10);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[1]='*';
            break;
        case '2':
            MotorAngel(11);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[2]='*';
            break;
        case '3':
            MotorAngel(12);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[3]='*';
            break;
        case '4':
            MotorAngel(13);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[4]='*';
            break;
        case '5':
            MotorAngel(14);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[5]='*';
            break;
        case '6':
            MotorAngel(15);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[6]='*';
            break;
        case '7':
            MotorAngel(16);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[7]='*';
            break;
        case '8':
            MotorAngel(17);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[8]='*';
            break;
        case '9':
            MotorAngel(0);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[9]='*';
            break;
        case 'a':
            MotorAngel(1);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[10]='*';
            break;
        case 'b':
            MotorAngel(2);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[11]='*';
            break;
        case 'c':
            MotorAngel(3);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[12]='*';
            break;
        case 'd':
            MotorAngel(4);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[13]='*';
            break;
        case 'e':
            MotorAngel(5);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[14]='*';
            break;
        case 'f':
            MotorAngel(6);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[15]='*';
            break;
        case 'g':
            MotorAngel(7);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[16]='*';
            break;
        case 'h':
            MotorAngel(8);
            SysCtlDelay(g_ui32SysClock/3);
            MotorPop();
            colorlist[17]='*';
            break;
        }
    }
}

//专门检测颜色传感器
void TestColor(void)
{
    while(1)
    {
        StringGet();
        Message("stopcolo");
        if(doit==1)
        {
            break;
        }
        Message("colocolo");
        if(doit==1)
        {
            ReadColor();
            UARTprintf("#%d %d %d %d%c#",c,r,g,b,colorget);
            while(1)
            {
                StringGet();
                Message("nextnext");
                if(doit==1)
                {
                    UARTprintf("#%d %d %d %d %c#",c,r,g,b,colorget);
                }
                Message("nicejob*");
                if(doit==1)
                {
                    break;
                }
            }
        }
    }
}

//专门检测距离传感器
void TestDistance(void)
{
    while(1)
    {
        StringGet();
        Message("stopdist");
        if(doit==1)
        {
            break;
        }
        Message("distdist");
        if(doit==1)
        {
            ReadDistance();
            UARTprintf("#dist:%d#",distance);
            while(1)
            {
                StringGet();
                Message("nextnext");
                if(doit==1)
                {
                    UARTprintf("#dist:%d#",distance);
                }
                Message("nicejob*");
                if(doit==1)
                {
                    break;
                }
            }
        }
    }
}

//专门检测读卡模块
void TestCard(void)
{
    while(1)
    {
        StringGet();
        Message("stopcard");
        if(doit==1)
        {
            break;
        }
        Message("cardcard");
        if(doit==1)
        {
            ReadCard();
            testcardbox[1]=cardflag1[0];
            testcardbox[2]=cardflag1[1];
            testcardbox[3]=cardflag1[2];
            testcardbox[4]=cardflag1[3];
            UARTSend((uint8_t *)testcardbox,6);
            while(1)
            {
                StringGet();
                Message("nextnext");
                if(doit==1)
                {
                    UARTSend((uint8_t *)testcardbox,6);
                }
                Message("nicejob*");
                if(doit==1)
                {
                    break;
                }
            }
        }
    }
}

//专门检测电机转动
void TestMotor(void)
{
    while(1)
    {
        StringGet();
        Message("stopmoto");
        if(doit==1)
        {
            break;
        }
        Message("motomoto");
        if(doit==1)
        {
            //转盘电机自检
            WritePin("00000");
            SysCtlDelay(g_ui32SysClock/6);
            WritePin("01001");
            SysCtlDelay(g_ui32SysClock/6);
            WritePin("00000");
            SysCtlDelay(g_ui32SysClock/6);
            //打出电机自检
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,GPIO_PIN_5);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,0);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,GPIO_PIN_5);
            //打入电机自检
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,0);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
            UARTSend((uint8_t *)"#motorcheck#",12);
            while(1)
            {
                StringGet();
                Message("nextnext");
                if(doit==1)
                {
                    UARTSend((uint8_t *)"#motorcheck#",12);
                }
                Message("nicejob*");
                if(doit==1)
                {
                    break;
                }
            }
        }
    }
}

void TestMode(void)
{
        UARTSend((uint8_t *)"IamReady",8);
        //检查颜色传感器
        StringGet();
        Message("testcolo");
        if(doit==1)
        {
            ReadColor();
            UARTprintf("%c",colorget);
        }
        //检查距离传感器
        StringGet();
        Message("testdist");
        if(doit==1)
        {
            ReadDistance();
            UARTprintf("%d",distance);
        }
        //检查读卡传感器
        StringGet();
        Message("testcard");
        if(doit==1)
        {
            ReadCard();
            UARTSend((uint8_t *)cardflag1,4);
        }
        //检查电机
        StringGet();
        Message("testmoto");
        if(doit==1)
        {
            //转盘电机自检
            WritePin("00000");
            SysCtlDelay(g_ui32SysClock/6);
            WritePin("01001");
            SysCtlDelay(g_ui32SysClock/6);
            WritePin("00000");
            SysCtlDelay(g_ui32SysClock/6);
            //打出电机自检
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,GPIO_PIN_5);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,0);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_5,GPIO_PIN_5);
            //打入电机自检
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,0);
            SysCtlDelay(g_ui32SysClock/6);
            GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
            //三个电机检测完成
            UARTSend((uint8_t *)"motorok*",8);
        }
}

void FuncMode(void)
{
    MotorAddScan();//首次添加货物，驱动电机完成一轮货物序列检测
    SendColorlist();//发送货物序列给PC
    while(1)
    {
        ReadDistance();//距离传感器持续工作，检测到有人靠近跳出循环
        LoopSend("sok*****");// 告诉PC有顾客来，开始工作
        if(breakflag==1) {break;}//若检测到补货命令，跳出funcmode
        ReadCard();//执行读卡程序
        LoopSend(allergy);//发送过敏原信息给PC
        ShippingGoods();//出指定种类和数量的货
        LoopSend("finishit");//告诉PC出货完毕
        SysCtlDelay(g_ui32SysClock);
    }
}

int main(void)
{
    InitAll();//初始化
    MotorReset();//电机复位
    while(1)
    {
        StringGet();//接收来自PC的字符串以决定采取哪种模式
        //自检模式
        Message("testmode");
        if(doit==1)
        {
            TestMode();
        }

        //颜色模块自检模式
        Message("colomode");
        if(doit==1)
        {
            TestColor();
        }

        //距离模块自检模式
        Message("distmode");
        if(doit==1)
        {
            TestDistance();
        }

        //读卡模块自检模式
        Message("cardmode");
        if(doit==1)
        {
            TestCard();
        }

        //电机模块自检模式
        Message("motomode");
        if(doit==1)
        {
            TestMotor();
        }

        //工作模式
        Message("funcmode");
        if(doit==1)
        {
            FuncMode();
        }
    }
}
